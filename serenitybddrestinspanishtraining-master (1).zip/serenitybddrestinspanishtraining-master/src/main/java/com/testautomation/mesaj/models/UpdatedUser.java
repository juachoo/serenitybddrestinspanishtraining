package com.testautomation.mesaj.models;

import lombok.Builder;
import lombok.Data;

public class UpdatedUser {
    private String name;
    private String job;
    private String updatedAt;
}
