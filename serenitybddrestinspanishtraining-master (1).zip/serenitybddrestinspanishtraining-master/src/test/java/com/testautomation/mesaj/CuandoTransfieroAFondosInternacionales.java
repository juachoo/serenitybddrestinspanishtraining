package com.testautomation.mesaj;

import org.junit.Test;

/*public class CuandoTransfieroAFondosInternacionales {

    @Test
    public void deberia_transferir_fondos_cuentas_locales(){}

    @Test
    public void deberia_transferir_fondos_cuentas_de_diferentesb_bancos(){}

    @Test
    public void deberia_deducir_las_tarifas_como_una_transaccion_aparte(){}

}*/
