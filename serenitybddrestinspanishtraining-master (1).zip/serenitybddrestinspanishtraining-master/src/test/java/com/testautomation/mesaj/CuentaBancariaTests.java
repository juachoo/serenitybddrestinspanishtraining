package com.testautomation.mesaj;

import org.junit.Test;

/*public class CuentaBancariaTests {

    @Test
    public void transfererencia(){}

    @Test
    public void deposito(){}

}*/
