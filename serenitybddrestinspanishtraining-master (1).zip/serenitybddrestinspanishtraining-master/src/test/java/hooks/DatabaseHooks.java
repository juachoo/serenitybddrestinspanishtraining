package hooks;

public class DatabaseHooks {
}
