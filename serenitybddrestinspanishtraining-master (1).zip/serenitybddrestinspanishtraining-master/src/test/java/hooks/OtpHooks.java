package hooks;

public class OtpHooks {
}
